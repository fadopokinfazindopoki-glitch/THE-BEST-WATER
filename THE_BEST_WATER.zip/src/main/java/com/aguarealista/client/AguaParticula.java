package com.aguarealista.client;

import com.aguarealista.Tipo;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;

public class AguaParticula extends TextureSheetParticle {
    private final Tipo tipo;
    private final float tam0;
    private float alfa0 = 1f;

    public AguaParticula(ClientLevel level, double x, double y, double z, double dx, double dy, double dz,
                         SpriteSet sprites, Tipo tipo) {
        super(level, x, y, z);
        this.tipo = tipo;
        this.pickSprite(sprites);
        this.xd = 0; this.yd = 0; this.zd = 0;
        this.gravity = 0f;
        this.friction = 1f;
        this.hasPhysics = false;

        switch (tipo) {
            case FLUIDO -> {
                float esp = (float) Math.max(0, Math.min(1, dx));
                this.lifetime = 2;
                this.quadSize = 0.085f;
                this.setColor(0.30f + 0.65f * esp, 0.62f + 0.36f * esp, 0.98f);
                this.alfa0 = 0.55f + 0.35f * esp;
            }
            case ESPUMA -> {
                float escala = dy > 0 ? (float) dy : 1f;
                this.lifetime = 18 + this.random.nextInt(18);
                this.quadSize = (0.16f + this.random.nextFloat() * 0.16f) * escala;
                this.xd = dx * 0.05; this.zd = dz * 0.05;
                this.setColor(0.96f, 0.99f, 1f);
                this.alfa0 = 0.85f;
            }
            case NEBLINA -> {
                float escala = dy > 0 ? (float) dy : 1f;
                this.lifetime = 30 + this.random.nextInt(30);
                this.quadSize = (0.25f + this.random.nextFloat() * 0.2f) * escala;
                this.xd = (this.random.nextDouble() - 0.5) * 0.02;
                this.yd = 0.010 + this.random.nextDouble() * 0.015;
                this.zd = (this.random.nextDouble() - 0.5) * 0.02;
                this.friction = 0.98f;
                this.setColor(0.93f, 0.97f, 1f);
                this.alfa0 = 0.30f;
            }
            case GOTA -> {
                this.lifetime = 8 + this.random.nextInt(14);
                this.quadSize = 0.03f + this.random.nextFloat() * 0.025f;
                this.xd = dx; this.yd = dy; this.zd = dz;
                this.gravity = 0.9f;
                this.friction = 0.98f;
                this.hasPhysics = true;
                this.setColor(0.85f, 0.94f, 1f);
                this.alfa0 = 0.95f;
            }
            case BOLHA -> {
                this.lifetime = 25 + this.random.nextInt(30);
                this.quadSize = 0.04f + this.random.nextFloat() * 0.05f;
                this.xd = dx; this.yd = 0.02 + this.random.nextDouble() * 0.02; this.zd = dz;
                this.gravity = -0.02f;
                this.friction = 0.97f;
                this.setColor(1f, 1f, 1f);
                this.alfa0 = 0.85f;
            }
        }
        this.tam0 = this.quadSize;
        this.setAlpha(tipo == Tipo.FLUIDO ? this.alfa0 : 0f);
        if (tipo == Tipo.GOTA || tipo == Tipo.BOLHA) this.setAlpha(this.alfa0);
    }

    @Override
    public void tick() {
        super.tick();
        float k = this.lifetime > 0 ? (float) this.age / (float) this.lifetime : 1f;
        switch (this.tipo) {
            case ESPUMA -> {
                this.setAlpha((float) Math.sin(Math.PI * Math.min(1f, k)) * this.alfa0);
                this.quadSize = this.tam0 * (0.8f + 0.4f * k);
            }
            case NEBLINA -> {
                this.setAlpha((float) Math.sin(Math.PI * Math.min(1f, k)) * this.alfa0);
                this.quadSize = this.tam0 * (1f + 1.6f * k);
            }
            case GOTA -> this.setAlpha(this.alfa0 * (1f - k * k * k));
            case BOLHA -> this.setAlpha(this.alfa0 * (1f - k * k));
            default -> { }
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }
}
