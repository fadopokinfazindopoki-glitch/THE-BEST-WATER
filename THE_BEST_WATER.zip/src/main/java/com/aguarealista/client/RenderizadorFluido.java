package com.aguarealista.client;

import java.nio.FloatBuffer;
import java.util.List;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL33;

import com.aguarealista.sim.Fluido;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.pipeline.RenderTarget;

/**
 * Renderização de fluido em espaço de tela (screen-space fluid rendering):
 * 1) esferas -> mapa de profundidade e espessura
 * 2) suavização bilateral da profundidade (junta as bolinhas numa superfície contínua)
 * 3) normais pela profundidade -> refração, reflexo do céu, brilho do sol, absorção e espuma
 * Se qualquer etapa falhar, desliga sozinho e o mod volta a desenhar bolinhas.
 */
public final class RenderizadorFluido {
    public static final RenderizadorFluido INSTANCE = new RenderizadorFluido();
    private static final org.slf4j.Logger LOG = LogUtils.getLogger();
    private static final float RAIO = 0.21f;

    private static volatile boolean falhou = false;

    public static boolean ativo() {
        return Config.I.superficie && !falhou;
    }

    // ---------------- shaders ----------------
    private static final String VS_PART = """
        #version 330 core
        layout(location=0) in vec3 aPos;
        uniform mat4 uView;
        uniform mat4 uProj;
        uniform float uRadius;
        out vec2 vCoord;
        out vec3 vCenter;
        const vec2 C[4] = vec2[4](vec2(-1.0,-1.0), vec2(1.0,-1.0), vec2(-1.0,1.0), vec2(1.0,1.0));
        void main(){
            vec2 c = C[gl_VertexID];
            vec4 vp = uView * vec4(aPos, 1.0);
            vCenter = vp.xyz;
            vCoord = c;
            vp.xy += c * uRadius;
            gl_Position = uProj * vp;
        }
        """;

    private static final String FS_COMMON = """
        #version 330 core
        in vec2 vCoord;
        in vec3 vCenter;
        uniform mat4 uProj;
        uniform float uRadius;
        uniform sampler2D uSceneDepth;
        uniform vec2 uFRes;
        """;

    private static final String FS_DEPTH = FS_COMMON + """
        layout(location=0) out float outDepth;
        void main(){
            float r2 = dot(vCoord, vCoord);
            if (r2 > 1.0) discard;
            float nz = sqrt(1.0 - r2);
            vec3 pv = vCenter + vec3(vCoord * uRadius, nz * uRadius);
            float eye = -pv.z;
            vec4 clip = uProj * vec4(pv, 1.0);
            float winZ = (clip.z / clip.w) * 0.5 + 0.5;
            vec2 uv = gl_FragCoord.xy / uFRes;
            float sd = texture(uSceneDepth, uv).r;
            float sEye = uProj[3][2] / (sd * 2.0 - 1.0 + uProj[2][2]);
            if (eye > sEye) discard;
            gl_FragDepth = winZ;
            outDepth = eye;
        }
        """;

    private static final String FS_THICK = FS_COMMON + """
        layout(location=0) out float outT;
        void main(){
            float r2 = dot(vCoord, vCoord);
            if (r2 > 1.0) discard;
            float nz = sqrt(1.0 - r2);
            vec3 pv = vCenter + vec3(vCoord * uRadius, nz * uRadius);
            float eye = -pv.z;
            vec2 uv = gl_FragCoord.xy / uFRes;
            float sd = texture(uSceneDepth, uv).r;
            float sEye = uProj[3][2] / (sd * 2.0 - 1.0 + uProj[2][2]);
            if (eye > sEye) discard;
            outT = 2.0 * nz * uRadius;
        }
        """;

    private static final String VS_FULL = """
        #version 330 core
        void main(){
            vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
            gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
        }
        """;

    private static final String FS_BLUR = """
        #version 330 core
        uniform sampler2D uSrc;
        uniform vec2 uDir;
        uniform vec2 uFRes;
        uniform float uFilter;
        out float o;
        void main(){
            ivec2 p = ivec2(gl_FragCoord.xy);
            float d = texelFetch(uSrc, p, 0).r;
            if (d <= 0.0) { o = 0.0; return; }
            float stepPx = clamp(uFilter / d, 1.0, 5.0);
            ivec2 mx = ivec2(uFRes) - 1;
            float sum = 0.0;
            float wsum = 0.0;
            for (int i = -8; i <= 8; i++) {
                ivec2 q = clamp(p + ivec2(round(uDir * float(i) * stepPx)), ivec2(0), mx);
                float s = texelFetch(uSrc, q, 0).r;
                if (s <= 0.0) continue;
                float dd = s - d;
                float w = exp(-float(i * i) / 32.0) * exp(-dd * dd / 0.05);
                sum += s * w;
                wsum += w;
            }
            o = wsum > 0.0 ? sum / wsum : d;
        }
        """;

    private static final String FS_COMP = """
        #version 330 core
        uniform sampler2D uDepth;
        uniform sampler2D uThick;
        uniform sampler2D uScene;
        uniform vec2 uRes;
        uniform vec2 uFRes;
        uniform vec2 uF;
        uniform mat3 uViewToWorld;
        uniform vec3 uSun;
        uniform float uLight;
        uniform float uTime;
        out vec4 fragColor;

        vec3 posAt(ivec2 p, float d){
            vec2 ndc = (vec2(p) + 0.5) / uFRes * 2.0 - 1.0;
            return vec3(ndc.x * d / uF.x, ndc.y * d / uF.y, -d);
        }

        void main(){
            vec2 uv = gl_FragCoord.xy / uRes;
            ivec2 p = ivec2(uv * uFRes);
            float d = texelFetch(uDepth, p, 0).r;
            if (d <= 0.0) discard;
            ivec2 mx = ivec2(uFRes) - 1;
            ivec2 pr = min(p + ivec2(2, 0), mx);
            ivec2 pl = max(p - ivec2(2, 0), ivec2(0));
            ivec2 pu = min(p + ivec2(0, 2), mx);
            ivec2 pd = max(p - ivec2(0, 2), ivec2(0));
            float dr = texelFetch(uDepth, pr, 0).r;
            float dl = texelFetch(uDepth, pl, 0).r;
            float du = texelFetch(uDepth, pu, 0).r;
            float dn = texelFetch(uDepth, pd, 0).r;
            vec3 P = posAt(p, d);
            vec3 ddx = vec3(0.01, 0.0, 0.0);
            vec3 ddy = vec3(0.0, 0.01, 0.0);
            if (dr > 0.0 && (dl <= 0.0 || abs(dr - d) < abs(d - dl))) ddx = posAt(pr, dr) - P;
            else if (dl > 0.0) ddx = P - posAt(pl, dl);
            if (du > 0.0 && (dn <= 0.0 || abs(du - d) < abs(d - dn))) ddy = posAt(pu, du) - P;
            else if (dn > 0.0) ddy = P - posAt(pd, dn);
            vec3 N = normalize(cross(ddx, ddy));
            if (N.z < 0.0) N = -N;
            vec3 V = normalize(-P);
            float t = texelFetch(uThick, p, 0).r;

            float ndv = clamp(dot(N, V), 0.0, 1.0);
            float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
            vec3 Rw = normalize(uViewToWorld * reflect(-V, N));
            float day = clamp(uSun.y * 1.6 + 0.35, 0.08, 1.0);
            vec3 skyTop = vec3(0.28, 0.50, 0.95) * day;
            vec3 skyHor = vec3(0.75, 0.85, 0.98) * day;
            vec3 sky = mix(skyHor, skyTop, pow(clamp(Rw.y, 0.0, 1.0), 0.5));
            sky = mix(sky, vec3(0.10, 0.12, 0.12) * day, clamp(-Rw.y * 3.0, 0.0, 1.0));
            float sunSpec = pow(max(dot(Rw, uSun), 0.0), 380.0) * 3.0 * day * step(0.0, uSun.y);

            vec2 off = N.xy * 0.06 * clamp(t * 0.7, 0.05, 1.0);
            vec3 bg = texture(uScene, clamp(uv + off, vec2(0.001), vec2(0.999))).rgb;
            vec3 absorb = vec3(0.55, 0.20, 0.10);
            vec3 trans = bg * exp(-absorb * t * 1.4);
            vec3 deep = vec3(0.02, 0.18, 0.28) * (0.35 + 0.65 * uLight);
            float depthMix = 1.0 - exp(-t * 0.9);
            vec3 body = mix(trans, deep, depthMix * 0.75);
            vec3 col = mix(body, sky * (0.45 + 0.55 * uLight), fres * 0.85);
            col += vec3(1.0, 0.98, 0.92) * sunSpec * uLight;

            float n = fract(sin(dot(gl_FragCoord.xy * 0.37 + uTime, vec2(12.9898, 78.233))) * 43758.5453);
            float edge = smoothstep(0.38, 0.0, t);
            float foam = edge * (0.55 + 0.45 * n);
            foam += smoothstep(0.55, 1.0, 1.0 - ndv) * 0.12 * n;
            col = mix(col, vec3(0.93, 0.97, 1.0) * (0.45 + 0.55 * uLight), clamp(foam, 0.0, 0.85));

            float a = smoothstep(0.0, 0.10, t);
            fragColor = vec4(clamp(col, 0.0, 1.0), a);
        }
        """;

    // ---------------- recursos GL ----------------
    private boolean pronto = false;
    private int progDepth, progThick, progBlur, progComp;
    private int vao, vbo;
    private int texDepthA, texDepthB, texThick, texScene, rbDepth, fboA, fboB, fboT;
    private int fw, fh, mw, mh;
    private final FloatBuffer buf = BufferUtils.createFloatBuffer(1500 * 3);
    private final float[] m4 = new float[16];
    private final float[] m3 = new float[9];

    private RenderizadorFluido() {}

    private static int compilar(int tipo, String fonte) {
        int s = GL20.glCreateShader(tipo);
        GL20.glShaderSource(s, fonte);
        GL20.glCompileShader(s);
        if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) {
            throw new IllegalStateException("shader: " + GL20.glGetShaderInfoLog(s, 4096));
        }
        return s;
    }

    private static int programa(String vs, String fs) {
        int v = compilar(GL20.GL_VERTEX_SHADER, vs);
        int f = compilar(GL20.GL_FRAGMENT_SHADER, fs);
        int p = GL20.glCreateProgram();
        GL20.glAttachShader(p, v);
        GL20.glAttachShader(p, f);
        GL20.glLinkProgram(p);
        if (GL20.glGetProgrami(p, GL20.GL_LINK_STATUS) == 0) {
            throw new IllegalStateException("link: " + GL20.glGetProgramInfoLog(p, 4096));
        }
        GL20.glDeleteShader(v);
        GL20.glDeleteShader(f);
        return p;
    }

    private void iniciar() {
        progDepth = programa(VS_PART, FS_DEPTH);
        progThick = programa(VS_PART, FS_THICK);
        progBlur = programa(VS_FULL, FS_BLUR);
        progComp = programa(VS_FULL, FS_COMP);
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 12, 0L);
        GL33.glVertexAttribDivisor(0, 1);
        pronto = true;
    }

    private static int criarTex(int interno, int formato, int tipo, int w, int h) {
        int t = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, t);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, interno, w, h, 0, formato, tipo, 0L);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        return t;
    }

    private static int criarFbo(int tex, int rbDepth) {
        int f = GL30.glGenFramebuffers();
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, f);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, tex, 0);
        if (rbDepth != 0) {
            GL30.glFramebufferRenderbuffer(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_RENDERBUFFER, rbDepth);
        }
        if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) != GL30.GL_FRAMEBUFFER_COMPLETE) {
            throw new IllegalStateException("framebuffer incompleto");
        }
        return f;
    }

    private void liberarBuffers() {
        if (fboA != 0) { GL30.glDeleteFramebuffers(fboA); GL30.glDeleteFramebuffers(fboB); GL30.glDeleteFramebuffers(fboT); }
        if (rbDepth != 0) GL30.glDeleteRenderbuffers(rbDepth);
        if (texDepthA != 0) { GL11.glDeleteTextures(texDepthA); GL11.glDeleteTextures(texDepthB); GL11.glDeleteTextures(texThick); GL11.glDeleteTextures(texScene); }
        fboA = fboB = fboT = rbDepth = texDepthA = texDepthB = texThick = texScene = 0;
    }

    private void garantirBuffers(int w, int h, double escala) {
        int nfw = Math.max(16, (int) (w * escala));
        int nfh = Math.max(16, (int) (h * escala));
        if (nfw == fw && nfh == fh && w == mw && h == mh && fboA != 0) return;
        liberarBuffers();
        fw = nfw; fh = nfh; mw = w; mh = h;
        texDepthA = criarTex(GL30.GL_R32F, GL11.GL_RED, GL11.GL_FLOAT, fw, fh);
        texDepthB = criarTex(GL30.GL_R32F, GL11.GL_RED, GL11.GL_FLOAT, fw, fh);
        texThick = criarTex(GL30.GL_R16F, GL11.GL_RED, GL11.GL_FLOAT, fw, fh);
        texScene = criarTex(GL11.GL_RGBA8, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, w, h);
        rbDepth = GL30.glGenRenderbuffers();
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, rbDepth);
        GL30.glRenderbufferStorage(GL30.GL_RENDERBUFFER, GL14.GL_DEPTH_COMPONENT24, fw, fh);
        fboA = criarFbo(texDepthA, rbDepth);
        fboB = criarFbo(texDepthB, 0);
        fboT = criarFbo(texThick, 0);
    }

    // ---------------- estado GL salvo/restaurado ----------------
    private static final class Estado {
        int ativa, prog, vao, arr, fboD, fboL, blend, depthTest, depthMask, depthFunc, cull, scissor;
        int sRgb, dRgb, sA, dA;
        final int[] tex = new int[4];
        final int[] vp = new int[4];

        void salvar() {
            ativa = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
            for (int u = 0; u < 4; u++) {
                GL13.glActiveTexture(GL13.GL_TEXTURE0 + u);
                tex[u] = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
            }
            GL13.glActiveTexture(ativa);
            prog = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
            vao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
            arr = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
            fboD = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
            fboL = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, vp);
            blend = GL11.glIsEnabled(GL11.GL_BLEND) ? 1 : 0;
            sRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
            dRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
            sA = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
            dA = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
            depthTest = GL11.glIsEnabled(GL11.GL_DEPTH_TEST) ? 1 : 0;
            depthMask = GL11.glGetInteger(GL11.GL_DEPTH_WRITEMASK);
            depthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
            cull = GL11.glIsEnabled(GL11.GL_CULL_FACE) ? 1 : 0;
            scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST) ? 1 : 0;
        }

        void restaurar() {
            for (int u = 0; u < 4; u++) {
                GL13.glActiveTexture(GL13.GL_TEXTURE0 + u);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex[u]);
            }
            GL13.glActiveTexture(ativa);
            GL20.glUseProgram(prog);
            GL30.glBindVertexArray(vao);
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arr);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, fboD);
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, fboL);
            GL11.glViewport(vp[0], vp[1], vp[2], vp[3]);
            set(GL11.GL_BLEND, blend);
            GL14.glBlendFuncSeparate(sRgb, dRgb, sA, dA);
            set(GL11.GL_DEPTH_TEST, depthTest);
            GL11.glDepthMask(depthMask != 0);
            GL11.glDepthFunc(depthFunc);
            set(GL11.GL_CULL_FACE, cull);
            set(GL11.GL_SCISSOR_TEST, scissor);
        }

        private static void set(int cap, int on) {
            if (on != 0) GL11.glEnable(cap); else GL11.glDisable(cap);
        }
    }

    // ---------------- desenho ----------------
    private static void mat4(Matrix4f m, float[] a) { m.get(a); }

    private void uni1i(int prog, String n, int v) { GL20.glUniform1i(GL20.glGetUniformLocation(prog, n), v); }
    private void uni1f(int prog, String n, float v) { GL20.glUniform1f(GL20.glGetUniformLocation(prog, n), v); }
    private void uni2f(int prog, String n, float a, float b) { GL20.glUniform2f(GL20.glGetUniformLocation(prog, n), a, b); }

    private void bindTex(int unit, int tex) {
        GL13.glActiveTexture(GL13.GL_TEXTURE0 + unit);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
    }

    public void renderizar(Minecraft mc, List<Fluido.P> ps) {
        if (falhou || !Config.I.superficie || ps.isEmpty()) return;
        ClientLevel lvl = mc.level;
        if (lvl == null) return;
        RenderTarget main = mc.getMainRenderTarget();
        int depthMain = main.getDepthTextureId();
        if (depthMain == 0) { falhou = true; LOG.warn("[THE BEST WATER] sem textura de profundidade; usando bolinhas"); return; }

        Estado st = new Estado();
        try {
            while (GL11.glGetError() != GL11.GL_NO_ERROR) { /* limpa erros antigos */ }
            st.salvar();
            if (!pronto) iniciar();

            Config.Nivel N = Config.nivel();
            int W = main.viewWidth, H = main.viewHeight;
            garantirBuffers(W, H, N.escala());

            // matrizes
            Camera cam = mc.gameRenderer.getMainCamera();
            Vec3 cp = cam.getPosition();
            Quaternionf q = cam.rotation();
            Matrix4f view = new Matrix4f().rotation(q.conjugate(new Quaternionf()));
            Matrix4f proj = new Matrix4f(RenderSystem.getProjectionMatrix());
            float parcial = mc.getTimer().getGameTimeDeltaPartialTick(false);

            // posições das partículas (camera-relativas, interpoladas)
            int n = Math.min(ps.size(), 1500);
            buf.clear();
            double sx = 0, sy = 0, sz = 0;
            for (int i = 0; i < n; i++) {
                Fluido.P p = ps.get(i);
                double x = p.ox + (p.x - p.ox) * parcial;
                double y = p.oy + (p.y - p.oy) * parcial;
                double z = p.oz + (p.z - p.oz) * parcial;
                sx += x; sy += y; sz += z;
                buf.put((float) (x - cp.x)).put((float) (y - cp.y)).put((float) (z - cp.z));
            }
            buf.flip();

            // luz e sol
            BlockPos cb = BlockPos.containing(sx / n, sy / n + 0.5, sz / n);
            float sky = lvl.getBrightness(LightLayer.SKY, cb) / 15f;
            float blk = lvl.getBrightness(LightLayer.BLOCK, cb) / 15f;
            float a = lvl.getTimeOfDay(parcial) * (float) (Math.PI * 2.0);
            float sunX = -(float) Math.sin(a), sunY = (float) Math.cos(a);
            float dia = Math.max(0.08f, Math.min(1f, sunY * 1.6f + 0.35f));
            float luz = Math.max(0.15f, Math.min(1f, Math.max(sky * dia, blk * 0.85f)));

            // upload das posições
            GL30.glBindVertexArray(vao);
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buf, GL15.GL_STREAM_DRAW);

            // cópia da cena (para refração)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
            bindTex(0, texScene);
            GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, W, H);

            GL11.glDisable(GL11.GL_SCISSOR_TEST);
            GL11.glDisable(GL11.GL_CULL_FACE);

            // ---- 1) profundidade das esferas ----
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboA);
            GL11.glViewport(0, 0, fw, fh);
            GL11.glColorMask(true, true, true, true);
            GL11.glDepthMask(true);
            GL30.glClearBufferfv(GL11.GL_COLOR, 0, new float[]{0f, 0f, 0f, 0f});
            GL30.glClearBufferfv(GL11.GL_DEPTH, 0, new float[]{1f});
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDepthFunc(GL11.GL_LESS);
            GL20.glUseProgram(progDepth);
            mat4(view, m4); GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(progDepth, "uView"), false, m4);
            mat4(proj, m4); GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(progDepth, "uProj"), false, m4);
            uni1f(progDepth, "uRadius", RAIO);
            uni2f(progDepth, "uFRes", fw, fh);
            bindTex(0, depthMain);
            uni1i(progDepth, "uSceneDepth", 0);
            GL31.glDrawArraysInstanced(GL11.GL_TRIANGLE_STRIP, 0, 4, n);

            // ---- 2) espessura ----
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboT);
            GL11.glViewport(0, 0, fw, fh);
            GL30.glClearBufferfv(GL11.GL_COLOR, 0, new float[]{0f, 0f, 0f, 0f});
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glEnable(GL11.GL_BLEND);
            GL14.glBlendFuncSeparate(GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ONE);
            GL20.glUseProgram(progThick);
            mat4(view, m4); GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(progThick, "uView"), false, m4);
            mat4(proj, m4); GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(progThick, "uProj"), false, m4);
            uni1f(progThick, "uRadius", RAIO);
            uni2f(progThick, "uFRes", fw, fh);
            bindTex(0, depthMain);
            uni1i(progThick, "uSceneDepth", 0);
            GL31.glDrawArraysInstanced(GL11.GL_TRIANGLE_STRIP, 0, 4, n);

            // ---- 3) suavização bilateral (A->B horizontal, B->A vertical) x2 ----
            GL11.glDisable(GL11.GL_BLEND);
            GL20.glUseProgram(progBlur);
            uni2f(progBlur, "uFRes", fw, fh);
            float focal = proj.m11() * fh * 0.5f;
            uni1f(progBlur, "uFilter", 0.12f * focal);
            uni1i(progBlur, "uSrc", 0);
            for (int it = 0; it < 2; it++) {
                GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboB);
                bindTex(0, texDepthA);
                uni2f(progBlur, "uDir", 1f, 0f);
                GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
                GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboA);
                bindTex(0, texDepthB);
                uni2f(progBlur, "uDir", 0f, 1f);
                GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
            }

            // ---- 4) composição sobre a cena ----
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, main.frameBufferId);
            GL11.glViewport(0, 0, W, H);
            GL11.glEnable(GL11.GL_BLEND);
            GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ZERO, GL11.GL_ONE);
            GL20.glUseProgram(progComp);
            bindTex(0, texDepthA);
            bindTex(1, texThick);
            bindTex(2, texScene);
            uni1i(progComp, "uDepth", 0);
            uni1i(progComp, "uThick", 1);
            uni1i(progComp, "uScene", 2);
            uni2f(progComp, "uRes", W, H);
            uni2f(progComp, "uFRes", fw, fh);
            uni2f(progComp, "uF", proj.m00(), proj.m11());
            new Matrix3f().set(q).get(m3);
            GL20.glUniformMatrix3fv(GL20.glGetUniformLocation(progComp, "uViewToWorld"), false, m3);
            GL20.glUniform3f(GL20.glGetUniformLocation(progComp, "uSun"), sunX, sunY, 0f);
            uni1f(progComp, "uLight", luz);
            uni1f(progComp, "uTime", (lvl.getGameTime() + parcial) * 0.05f);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);

            int err = GL11.glGetError();
            if (err != GL11.GL_NO_ERROR) throw new IllegalStateException("erro GL 0x" + Integer.toHexString(err));
        } catch (Throwable e) {
            falhou = true;
            LOG.error("[THE BEST WATER] renderizador de superfície desligado, voltando às bolinhas", e);
        } finally {
            try { st.restaurar(); } catch (Throwable ignored) { }
        }
    }
}
