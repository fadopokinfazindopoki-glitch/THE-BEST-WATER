package com.aguarealista;

import java.util.EnumMap;
import java.util.Map;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

public final class ModParticulas {
    private static final Map<Tipo, SimpleParticleType> TIPOS = new EnumMap<>(Tipo.class);

    private ModParticulas() {}

    public static void registrar() {
        for (Tipo t : Tipo.values()) {
            SimpleParticleType p = FabricParticleTypes.simple();
            Registry.register(BuiltInRegistries.PARTICLE_TYPE,
                    ResourceLocation.fromNamespaceAndPath(AguaRealista.ID, t.name().toLowerCase()), p);
            TIPOS.put(t, p);
        }
    }

    public static SimpleParticleType get(Tipo t) {
        return TIPOS.get(t);
    }
}
